# Suggested initial pull requests

**PR-001** — Repo policy, model identity, provenance receipt, reference GR control, fail-closed observable permissions (current scaffold). Test on Linux and Windows.

**PR-002** — Restore June 2026 runnable J2141 + Set A under `backends/legacy_june/` with exact archived frozen source/data identities, replay and regression evidence. Include sensitivity/ablation outcomes as negative-regime tests. No physics rewrite.

**PR-003** — Restore original June low-temperature background package, regenerate full source integrator if absent; verify 420 rows without changing the original branch. Preserve provenance of 601-row variable-Planck Addendum G G-D background as a *separate* model.

**PR-004** — Source-derive current fixed-M_P/one-map v1.7.2 P1R VC1. Run independent Radau, DOP853, RK4, entropy current, full MEM, Friedmann and Bianchi gates. Keep BG8/P2 successor distinct.

**PR-005** — Connect external CLASS untouched for GR controls. Add PRECISE ESET perturbation and unit/gauge convention contract; no survey products until independent physical P3 provider is admitted.

**PR-006** — PRIMAT + HYREC-2 reference adapters; explicitly reject custom-background instantaneous-neutrino substitution for complete SM kinetic source. All source-uncertain interfaces fail closed.

**PR-007** — Frozen analysis integration (Cobaya, TreeCorr, lenstronomy, CCL), evidence provenance, independent holdouts; never use validation data to select model or provider normalization.
