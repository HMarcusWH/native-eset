# Native ESET — source-gated research repository bootstrap

> **Research software, not a validated cosmological model.** The reference controls in this bootstrap are *not* ESET predictions. No physical ESET provider is admitted by this starter.

This repository provides a clean control plane for independently versioned physical backends, strict reproducibility identities, solver adapters, and observation gates.

## The three separate branches

| Backend identity | Target | First milestone |
| --- | --- | --- |
| `legacy-june-eset3-4` | Recover archived historical code and published/recorded controls without revision | exact historical cold replay |
| `legacy-june-gd-variable-f` | Addendum G scalar–tensor `F(z)=z²` candidate (not equivalent to fixed M_P) | reproduce the frozen 601-row residual/solution object |
| `native-v1.7.2-one-map` | Fixed-Planck-mass Einstein frame; one material map, scalar, elastic and entropy-complete bulk MEM | reproduce P1R VC1, then physically couple BG8/P2/P3 successors |

Do not insert the ESET-3 independent displacement or a varying `M_*²(χ)R` term into v1.7.2 under the guise of a parameter update.

## Quickstart

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e '.[dev]'
pytest -q
python -m native_eset status
python -m native_eset control --z 0 1 3
```

`control` reports an **external GR/ΛCDM control** expansion curve, *not a Native ESET physical model*. It does not claim ΛCDM as the Native off state.

## Third-party strategy

Never blindly merge or vendor outside cosmology source trees. Use pin-able external adapters, exact upstream Git SHA/release, attributed licenses, and provenance receipts. See `docs/dependencies.md` and `config/upstream_adapters.json`.

## Current scientific status

No full ESET physical cosmology has been admitted by this starter. Its source contracts preserve the present finite background / formal-gate boundaries and inherited blockers. An executable physical backend must ship action identities, source implementation, coupled field equations, numerical convergence, stress/Bianchi constraints, physical species/radiation, and provider/observable test coverage before requesting promotion.

## Where the June audit is stored

June 27, 2026 model recovery and October 27, 2026 audit were archived separately in Google Drive. The historical audit package is https://drive.google.com/file/d/1yR0Vxl4tBrwAhknj9QrmADiSAm7jD2NA/view and the root is https://drive.google.com/drive/folders/1L2ZPDy2GfMJCCS4CtYDayZaCGFSMRAIJ .

## Publication and licensing

No license is selected for new ESET code in this draft. Decide a license before publishing; examine original June code and all third-party license terms separately. This starter bundles **no third-party source code**, original data, large private archives, observational catalogs or physics implementations disguised as complete solvers.
