"""Optional CLASS adapter; library remains an independent reference dependency.

No ESET-specific metric/sources are inserted or claimed here.
"""
from typing import Any


def class_reference_run(parameters: dict[str, Any]) -> dict[str, Any]:
    try:
        from classy import Class  # type: ignore
    except ImportError as exc:
        raise RuntimeError("Install CLASS/classy separately and pin a verified version") from exc
    cosmo = Class()
    try:
        cosmo.set(parameters)
        cosmo.compute()
        return {"backend": "CLASS_REFERENCE_ONLY", "input_parameters": dict(parameters),
                "computed": True, "physical_eset_provider_admitted": False}
    finally:
        cosmo.struct_cleanup()
        cosmo.empty()
