"""Fail-closed scientific output admission. Never promote an internal regression result."""
from dataclasses import dataclass
from enum import Enum


class ClaimStatus(str, Enum):
    SPECIFIED = "specified"
    INTERNAL_PASS = "internal_pass"
    OPEN_BLOCKING = "open_blocking"
    FAILED = "failed"
    PHYSICAL_PROVIDER_ADMITTED = "physical_provider_admitted"
    HOLDOUT_VALIDATED = "holdout_validated"


class AdmissionError(RuntimeError):
    pass


@dataclass(frozen=True)
class Admission:
    provider_id: str
    status: ClaimStatus = ClaimStatus.OPEN_BLOCKING
    physical_outputs: tuple[str, ...] = ()
    evidence_hash: str | None = None

    def authorize(self, observable: str) -> None:
        if self.status not in {ClaimStatus.PHYSICAL_PROVIDER_ADMITTED,
                               ClaimStatus.HOLDOUT_VALIDATED}:
            raise AdmissionError(f"{self.provider_id}: physical provider not admitted")
        if observable not in self.physical_outputs:
            raise AdmissionError(f"{self.provider_id}: {observable!r} not in authorized outputs")
        if not self.evidence_hash:
            raise AdmissionError(f"{self.provider_id}: no registered evidence envelope")
