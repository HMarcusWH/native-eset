"""Simple no-side-effect smoke commands."""
import argparse
import json
from native_eset.controls import FlatGRLambdaCDM


def main() -> int:
    parser = argparse.ArgumentParser(prog="eset")
    subs = parser.add_subparsers(dest="command", required=True)
    subs.add_parser("status")
    control = subs.add_parser("control")
    control.add_argument("--z", nargs="+", type=float, default=[0.0, 1.0, 3.0])
    args = parser.parse_args()
    if args.command == "status":
        print(json.dumps({
            "repo": "Native ESET research bootstrap",
            "science_status": "INFRASTRUCTURE_ONLY_NOT_A_PHYSICAL_ESET_PROVIDER",
            "legacy_june_backend": "not imported",
            "native_v1_7_2_backend": "not imported",
            "physical_outputs_authorized": [],
        }, indent=2))
    elif args.command == "control":
        model = FlatGRLambdaCDM()
        print(json.dumps({"control": "EXTERNAL_GR_LAMBDA_CDM_NOT_NATIVE_ESET",
                          "E_of_z": [{"z": z, "E": model.E(z)} for z in args.z]}, indent=2))
    return 0
